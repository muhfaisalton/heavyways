<?php
	include("cekKoneksi.php");
	$sql = "SELECT * FROM leaseform";
	$result = mysqli_query($koneksi, $sql);
	$nilai;
?>
<html>
    <head>
        <title>Web Heavyways</title>
        <link rel="stylesheet" href="css1/main.css" />
    </head>
    <body>

        <!-- Header -->
        <section id="header">
            <header>
                <span class="image avatar"><img src="images/logoHeavyway.png" alt="" /></span>
                <h1 id="logo"><a href="#">Heavyways</a></h1>
                <p></p>
            </header>
            <nav id="nav">
                <ul>
                    <li><a href="#one" class="active">Tabel Form Sewa</a></li> 
                    <li><a href="MenuAdmin.php">Menu Utama</a></li>
                </ul>
            </nav>
        </section>

        <!-- Wrapper -->
        <div id="wrapper">

            <!-- Main -->
            <div id="main">

                <!-- One -->
                <section id="one">
                    <div class="container">
                        <header class="major">
                            <h2>Lease Form List</h2>
                        </header>
				<fieldset>
                <table border=1>
				<tr>
					<th>Nama Perusahaan</th>
					<th>Nama Barang</th>
					<th>Tanggal Peminjaman</th>
					<th>Tanggal Kembali</th>
				</tr>
				<?php
					while($row = mysqli_fetch_array($result)){					
				?>
				<tr>
					<td><?php echo $row[0]; ?></td>
					<td><?php echo $row[1]; ?></td>
					<td><?php echo $row[2]; ?></td>
					<td><?php echo $row[3]; ?></td>
				</tr>
				<?php } ?>
				</fieldset>	
				</table>
				</fieldset>
	 </section>
                <!-- Scripts -->
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery.scrollzer.min.js"></script>
                <script src="js/jquery.scrolly.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/util.js"></script>
                <script src="js/main.js"></script>
               
                </body>
                </html>

				
				
							

