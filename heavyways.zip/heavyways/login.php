<?php
	session_start();
	include("cekKoneksi.php");
	$koneksi = mysqli_connect($lokasi_db, $usr, $pas, $nama_db, 3306);
	mysqli_select_db($koneksi, $nama_db);
	$sql = "SELECT * FROM daftar";
	$result = mysqli_query($koneksi, $sql);
	$nilai;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Web Heavyways</title>
        <link rel="stylesheet" href="css1/main.css" />
    </head>
    <body>

        <!-- Header -->
        <section id="header">
            <header>
                <span class="image avatar"><img src="images/logoHeavyway.png" alt="" /></span>
                <h1 id="logo"><a href="#">Heavyways</a></h1>
                <p></p>
            </header>
            <nav id="nav">
                <ul>
					<li><a href="#one" class="active">Daftar</a></li> 
                    <li><a href="Homepage.php">Menu Utama</a></li>
                </ul>
            </nav>
        </section>

        <!-- Wrapper -->
        <div id="wrapper">

            <!-- Main -->
            <div id="main">

                <!-- One -->
                <section id="one">
                    <div class="container">
                        <header class="major">
                            <h2>Login</h2>
                        </header>
                        <form method="post" action="Session_Proses.php">
                            <tr>
                                <td>Username</td>
                                <input type="text" id="Username" name="Username" placeholder="Username" />
                                <td>Password</td>
                                <input type="password" id="Password" name="Password" placeholder="Password" />
                                <input type="submit" onclick="submit()" class="special" value="Login" />
                        </tr>
                        </form>
                    </div>
                </section>
                <!-- Scripts -->
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery.scrollzer.min.js"></script>
                <script src="js/jquery.scrolly.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/util.js"></script>
                <script src="js/main.js"></script>
              
	 

                </body>
                </html>