<?php
include("cekKoneksi.php");
	$sql = "SELECT * FROM alat_db";
	$result = mysqli_query($koneksi, $sql);
	$nilai;
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Web Heavyways</title>
        <link rel="stylesheet" href="css1/main.css" />
    </head>
    <body>

        <!-- Header -->
        <section id="header">
            <header>
                <span class="image avatar"><img src="images/logoHeavyway.png" alt="" /></span>
                <h1 id="logo"><a href="#">Heavyways</a></h1>
                <p></p>
            </header>
            <nav id="nav">
                <ul>
                    <li><a href="#one" class="active">Tabel Daftar Pesan</a></li> 
                    <li><a href="Menu.php">Menu Utama</a></li>
                </ul>
            </nav>
        </section>

        <!-- Wrapper -->
        <div id="wrapper">

            <!-- Main -->
            <div id="main">

                <!-- One -->
                <section id="one">
                    <div class="container">
                        <header class="major">
                            <h2>Stock Item</h2>
                        </header>
                       <fieldset>
							<table>
							<tr>
							 <th>Nama Alat</th>
							 <th>ID</th>
							 <th>Model</th>
							 <th>Jumlah</th>
							 <th>Status</th>
						   </tr>
					<?php
					 while($row = mysqli_fetch_array($result)){
					   if($row[3]>0){
						 $status = "tersedia";
					   }else{
						 $status = "tidak tersedia";
					   }
				    ?>
				   <tr>
						 <td><?php echo $row[0]; ?></td>
						 <td><?php echo $row[1]; ?></td>
						 <td><?php echo $row[2]; ?></td>
						 <td><?php echo $row[3]; ?></td>
						 <td><?php echo $status ?></td>
				   </tr>
					  
				   <?php } ?>
					<tr>
						<td><a href="AddStock.php"><input type="button" name="Add" id="Add" onclick="Add()" class="special" value="Add"></a></td>
						<td><a href="updateStock.php"><input type="button" name="Update" id="Update" onclick="Update()" class="special" value="Update"></a></td>
						<td><a href="DeleteStock.php"><input type="button" name="Delete" id="Delete" onclick="Delete()" class="special" value="Delete"></a></td>
					</tr>


				</fieldset>
						</table>
                            
                                
                                
                        </form>
                    </div>
                </section>
                <!-- Scripts -->
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery.scrollzer.min.js"></script>
                <script src="js/jquery.scrolly.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/util.js"></script>
                <script src="js/main.js"></script>
               
                </body>
                </html>
