<?php
	$usr = "root";
	$pas = "";
	$lokasi_db = "localhost";
	$nama_db = "heavyways";
	//$nama_db merupakan nama database dimana data akan dimasukkan

	$koneksi = mysqli_connect($lokasi_db, $usr, $pas, $nama_db, 3306);
	//Digunakan untuk membuat hubungan antara php ke database MySQL
	mysqli_select_db($koneksi, $nama_db);
	//Digunakan untuk memilih database yang akan digunakan

	$mNamaPerusahaan = $_POST["NamaAlat"];
	$mID = $_POST["ID"];
	$mModel = $_POST["Model"];
	$mJumlah = $_POST["Jumlah"];

	$query_insert = "INSERT INTO service VALUES ('".$mNamaBarang."','".$mID."','".$mModel."','".$mModel."','".$mJumlah."')";
	//Query diatas digunakan untuk memasukkan data ke dalam database
	//('','','','','') <- Merupakan data yang ingin dimasukkan ke dalam database
	//jika di dalam database terdapat lebih dari 5 kolom maka bisa dimasukkan lagi kutip baru contoh ('')
	//isi dari '' bisa di isi dengan huruf langsung atau dengan '.$GET_[namaVariable].'

	if(mysqli_query($koneksi, $query_insert)){
		header('Location: service.php');
	}else{
		header('Location: service.php');
	}
	//Fungsi yang digunakan untuk melaksanakan query untuk memasukkan data
?>
