<?php
	$usr = "root";
	$pas = "";
	$lokasi_db = "localhost";
	$nama_db = "heavyways";
	
	$koneksi = mysqli_connect($lokasi_db, $usr, $pas, $nama_db, 3306);
	mysqli_select_db($koneksi, $nama_db);
	$sql = "SELECT * FROM daftar";
	$result = mysqli_query($koneksi, $sql);
	$nilai;
?>
<html>
    <head>
        <title>Web Heavyways</title>
        <link rel="stylesheet" href="css1/main.css" />
    </head>
    <body>

        <!-- Header -->
        <section id="header">
            <header>
                <span class="image avatar"><img src="images/logoHeavyway.png" alt="" /></span>
                <h1 id="logo"><a href="#">Heavyways</a></h1>
                <p></p>
            </header>
            <nav id="nav">
                <ul>
                    <li><a href="#one" class="active">Daftar User</a></li> 
                    <li><a href="MenuAdmin.php">Menu Utama</a></li>
                </ul>
            </nav>
        </section>

        <!-- Wrapper -->
        <div id="wrapper">

            <!-- Main -->
            <div id="main">

                <!-- One -->
                <section id="one">
                    <div class="container">
                        <header class="major">
                            <h2>User List</h2>
                        </header>
                          <table>
							<tr>
								<th>Nama Perusahaan</th>
								<th>Alamat</th>
								<th>Username</th>
								<th>Password</th>
							
							</tr>
							<?php
					while($row = mysqli_fetch_array($result)){					
				?>
				<tr>
					<td><?php echo $row[0]; ?></td>
					<td><?php echo $row[1]; ?></td>
					<td><?php echo $row[2]; ?></td>
					<td><?php echo $row[3]; ?></td>
				</tr>
				<?php } ?>
				</fieldset>
						</table>	
                        </form>
                    </div>
                </section>
                <!-- Scripts -->
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery.scrollzer.min.js"></script>
                <script src="js/jquery.scrolly.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/util.js"></script>
                <script src="js/main.js"></script>
               
                </body>
                </html>
