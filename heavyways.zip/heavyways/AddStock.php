<?php
	include("cekKoneksi.php");
	$sql = "SELECT * FROM alat_db";
	$result = mysqli_query($koneksi, $sql);
  $nilai;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Web Heavyways</title>
        <link rel="stylesheet" href="css1/main.css" />
    </head>
    <body>

        <!-- Header -->
        <section id="header">
            <header>
                <span class="image avatar"><img src="images/logoHeavyway.png" alt="" /></span>
                <h1 id="logo"><a href="#">Heavyways</a></h1>
                <p></p>
            </header>
            <nav id="nav">
                <ul>
                    <li><a href="#one" class="active">Add Stock</a></li> 
                    <li><a href="MenuVendor.php">Menu Utama</a></li>
                </ul>
            </nav>
        </section>

        <!-- Wrapper -->
        <div id="wrapper">

            <!-- Main -->
            <div id="main">

                <!-- One -->
                <section id="one">
                    <div class="container">
                        <header class="major">
                            <h2>Tambahkan Stock</h2>
                        </header>
                        <form method="post" action="insertAlat.php">
                            <tr>
								<td>Nama Alat</td>
                                <input type="text" id="NamaAlat" name="NamaAlat" placeholder="Nama Alat" />
								<td>ID Barang</td>
                               <input type="text" id="ID" name="ID" placeholder="ID Barang" />
                                <td>Model</td>
                                <input type="text" id="Model" name="Model" placeholder="Model" />
                                <td>Jumlah</td>
                                <input type="text" id="Jumlah" name="Jumlah" placeholder="Jumlah" />
                                <input type="submit" onclick="submit()" class="special" value="Add" />
                        </tr>
                        </form>
                    </div>
                </section>
                <!-- Scripts -->
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery.scrollzer.min.js"></script>
                <script src="js/jquery.scrolly.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/util.js"></script>
                <script src="js/main.js"></script>
              
	 

                </body>
                </html>