<?php
	include("cekKoneksi.php");
	$sql = "SELECT * FROM leaseform";
	$result = mysqli_query($koneksi, $sql);
	$nilai;
?>
<html>
    <head>
        <title>Web Heavyways</title>
        <link rel="stylesheet" href="css1/main.css" />
    </head>
    <body>

        <!-- Header -->
        <section id="header">
            <header>
                <span class="image avatar"><img src="images/logoHeavyway.png" alt="" /></span>
                <h1 id="logo"><a href="#">Heavyways</a></h1>
                <p></p>
            </header>
            <nav id="nav">
                <ul>
                    <li><a href="#one" class="active">Form Sewa</a></li> 
                    <li><a href="Menu.php">Menu Utama</a></li>
                </ul>
            </nav>
        </section>

        <!-- Wrapper -->
        <div id="wrapper">

            <!-- Main -->
            <div id="main">

                <!-- One -->
                <section id="one">
                    <div class="container">
                        <header class="major">
                            <h2>Form Sewa</h2>
                        </header>
                        <form method="post" action="insertlease.php">
                            <tr>
                                <td>Nama perusahaan : </td>
                                <input type="text" id="NamaPerusahaan" name="NamaPerusahaan" placeholder="Nama Perusahaan"/>
								 <td>Nama : </td>
                                <input type="text" id="Nama" name="Nama" placeholder="Nama"/>
                                <td>Nama Barang : </td>
                                <input type="text" id="NamaBarang" name="NamaBarang" placeholder="Nama Barang"/>
                                <td>Tanggal Peminjaman : </td>
                                <input type="text" id="TanggalPeminjaman" name="TanggalPeminjaman" placeholder="YYYY-MM-DD"/>
                                <td>Tanggal Kembali : </td>
                                <input type="text" id="TanggalKembali" name="TanggalKembali" placeholder="YYYY-MM-DD"/>
                                <input type="submit" onclick="submit()" class="special" value="Submit" />                   
                                
                        </form>
                    </div>
                </section>
                <!-- Scripts -->
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery.scrollzer.min.js"></script>
                <script src="js/jquery.scrolly.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/util.js"></script>
                <script src="js/main.js"></script>
               
                </body>
                </html>
