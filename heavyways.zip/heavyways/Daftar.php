<?php
	include("cekKoneksi.php");
	$sql = "SELECT * FROM Daftar";
	$result = mysqli_query($koneksi, $sql);
	$nilai;
?>
<html>
    <head>
        <title>Web Heavyways</title>
        <link rel="stylesheet" href="css1/main.css" />
    </head>
    <body>

        <!-- Header -->
        <section id="header">
            <header>
                <span class="image avatar"><img src="images/logoHeavyway.png" alt="" /></span>
                <h1 id="logo"><a href="#">Heavyways</a></h1>
                <p></p>
            </header>
            <nav id="nav">
                <ul>
                    <li><a href="#one" class="active">Daftar</a></li> 
                    <li><a href="Homepage.php">Menu Utama</a></li>
                </ul>
            </nav>
        </section>

        <!-- Wrapper -->
        <div id="wrapper">

            <!-- Main -->
            <div id="main">

                <!-- One -->
                <section id="one">
                    <div class="container">
                        <header class="major">
                            <h2>Daftar</h2>
                        </header>
                        <form method="post" action="InsertDaftar.php">
                            <tr>
                                <td>Nama Perusahaan</td>
                                <input type="text" id="NamaPerusahaan" name="NamaPerusahaan" placeholder="NamaPerusahaan" />
								<td>Alamat</td>
                                <input type="text" id="Alamat" name="Alamat" placeholder="Alamat" />
                                <td>Username</td>
                                <input type="text" id="Username" name="Username" placeholder="Username" />
                                <td>Password</td>
                                <input type="Password" id="Password" name="Password" placeholder="Password" />
                                <input type="submit" onclick="submit()" class="special" value="Daftar" />
                        </tr>
                        </form>
                    </div>
                </section>
                <!-- Scripts -->
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery.scrollzer.min.js"></script>
                <script src="js/jquery.scrolly.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/util.js"></script>
                <script src="js/main.js"></script>
              
	 

                </body>
                </html>