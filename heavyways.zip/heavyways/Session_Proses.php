<?php
//SESSION START HARUS DILAKUKAN SEBELUM MENGGUNAKAN FUNGSI SESSION
session_start();
include('cekKoneksi.php');
	$user = $_POST['Username'];
	$pass = $_POST['Password'];
	$query = "SELECT * FROM daftar WHERE Username = '$user' AND Password = '$pass'";
	$result = mysqli_query($koneksi, $query);
	
	if(mysqli_num_rows($result)!=0){
	$row = mysqli_fetch_array($result);
	  //$_SESSION BERARTI KITA MEMASUKKAN DATA KE DALAM SESSION YANG BERNAMA user_data DAN user_level
	  $_SESSION['user_data'] = $row[2];
	  $_SESSION['user_level'] = $row[4];
	  //KONDISI DIBAWAH DIGUNAKAN UNTUK MENGECEK SIAPA YANG LOG IN, JIKA LEBIH DARI 2 MAKA GUNAKAN ELSE IF
	  if ($_SESSION['user_level'] == 'Admin') {
		header('Location: MenuAdmin.php');
	  }else if($_SESSION['user_level'] == 'user'){
		  header('Location: Menu.php');
	  }else{
		  header('Location: MenuVendor.php');
	  }
	}else {
	  echo "Gagal";
	}
	?>