<?php
	include("cekKoneksi.php");
	$mID = $_GET["ID"];
	
	$query_insert = "DELETE FROM heavyways WHERE ID='".$mID."'";
	//Query diatas digunakan untuk memasukkan data ke dalam database
	//('','','','','') <- Merupakan data yang ingin dimasukkan ke dalam database
	//jika di dalam database terdapat lebih dari 5 kolom maka bisa dimasukkan lagi kutip baru contoh ('')
	//isi dari '' bisa di isi dengan huruf langsung atau dengan '.$GET_[namaVariable].'
	
	if(mysqli_query($koneksi, $query_insert)){
		header('Location: StockItem.php');
	}else{
		header('Location: StockItem.php');
	}
	//Fungsi yang digunakan untuk melaksanakan query untuk memasukkan data
?>