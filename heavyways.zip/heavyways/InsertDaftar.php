<?php
	include("cekKoneksi.php");
	$mNamaPerusahaan = $_POST["NamaPerusahaan"];
	$mAlamat = $_POST["Alamat"];
	$mUser = $_POST["Username"];
	$mPassword = $_POST["Password"];
	
	$query_insert = "INSERT INTO daftar VALUES ('".$mNamaPerusahaan."','".$mAlamat."','".$mUser."','".$mPassword."','user')";
	//Query diatas digunakan untuk memasukkan data ke dalam database
	//('','','','','') <- Merupakan data yang ingin dimasukkan ke dalam database
	//jika di dalam database terdapat lebih dari 5 kolom maka bisa dimasukkan lagi kutip baru contoh ('')
	//isi dari '' bisa di isi dengan huruf langsung atau dengan '.$GET_[namaVariable].'
	
	if(mysqli_query($koneksi, $query_insert)){
		header('Location: Daftar.php');
	}else{
		header('Location: Daftar.php');
	}
	//Fungsi yang digunakan untuk melaksanakan query untuk memasukkan data
?>