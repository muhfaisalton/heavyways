<?php
	include("cekKoneksi.php");
	$sql = "SELECT * FROM alat_db";
	$result = mysqli_query($koneksi, $sql);
  $nilai;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Web Heavyways</title>
        <link rel="stylesheet" href="css1/main.css" />
    </head>
    <body>

        <!-- Header -->
        <section id="header">
            <header>
                <span class="image avatar"><img src="images/logoHeavyway.png" alt="" /></span>
                <h1 id="logo"><a href="#">Heavyways</a></h1>
                <p></p>
            </header>
            <nav id="nav">
                <ul>
                    <li><a href="#one" class="active">Add Employee</a></li> 
                    <li><a href="MenuVendor.php">Menu Utama</a></li>
                </ul>
            </nav>
        </section>

        <!-- Wrapper -->
        <div id="wrapper">

            <!-- Main -->
            <div id="main">

                <!-- One -->
                <section id="one">
                    <div class="container">
                        <header class="major">
                            <h2>Add Employee</h2>
                        </header>
                        <form method="post" action="insertPegawai.php">
                            <tr>
								<td>Nama Depan</td>
                                <input type="text" id="NamaDepan" name="NamaDepan" placeholder="Nama Depan" />
								<td>Nama Belakang</td>
                               <input type="text" id="NamaBelakang" name="NamaBelakang" placeholder="Nama Belakang" />
                                <td>Organization</td>
                                <input type="text" id="Organization" name="Organization" placeholder="Organization" />
                                <td>Job Position</td>
                                <input type="text" id="JobPosition" name="JobPosition" placeholder="Job Position" />
								<td>Job Title</td>
								<input type="text" id="JobTitle" name="JobTitle" placeholder="Job Title" />
								<td>Company Work</td>
								<input type="text" id="CompanyWork" name="CompanyWork" placeholder="Company Work" />
                                <input type="submit" onclick="submit()" class="special" value="Add" />
                        </tr>
                        </form>
                    </div>
                </section>
                <!-- Scripts -->
                <script src="js/jquery.min.js"></script>
                <script src="js/jquery.scrollzer.min.js"></script>
                <script src="js/jquery.scrolly.min.js"></script>
                <script src="js/skel.min.js"></script>
                <script src="js/util.js"></script>
                <script src="js/main.js"></script>
              
	 

                </body>
                </html>